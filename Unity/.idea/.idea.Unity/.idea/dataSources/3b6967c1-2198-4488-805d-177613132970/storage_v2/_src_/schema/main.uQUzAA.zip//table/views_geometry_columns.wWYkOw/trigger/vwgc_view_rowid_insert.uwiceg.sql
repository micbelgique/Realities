CREATE TRIGGER vwgc_view_rowid_insert
BEFORE INSERT ON 'views_geometry_columns'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on views_geometry_columns violates constraint: view_rowid value must not contain a single quote')
WHERE NEW.view_rowid LIKE ('%''%');
SELECT RAISE(ABORT,'insert on views_geometry_columns violates constraint: 
view_rowid value must not contain a double quote')
WHERE NEW.view_rowid LIKE ('%"%');
SELECT RAISE(ABORT,'insert on views_geometry_columns violates constraint: view_rowid value must be lower case')
WHERE NEW.view_rowid <> lower(NEW.view_rowid);
END;

