CREATE TRIGGER vwgcau_view_name_update
BEFORE UPDATE OF 'view_name' ON 'views_geometry_columns_auth'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'update on views_geometry_columns_auth violates constraint: view_name value must not contain a single quote')
WHERE NEW.view_name LIKE ('%''%');
SELECT RAISE(ABORT,'update on views_geometry_columns_auth violates constraint: view_name value must not contain a double quote')
WHERE NEW.view_name LIKE ('%"%');
SELECT RAISE(ABORT,'update on views_geometry_columns_auth violates constraint: view_name value must be lower case')
WHERE NEW.view_name <> lower(NEW.view_name);
END;

