CREATE TRIGGER geometry_columns_coord_dimension_update
BEFORE UPDATE OF 'coord_dimension' ON 'geometry_columns'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'coord_dimension must be one of 2,3,4')
WHERE NOT(NEW.coord_dimension IN (2,3,4));
END;

