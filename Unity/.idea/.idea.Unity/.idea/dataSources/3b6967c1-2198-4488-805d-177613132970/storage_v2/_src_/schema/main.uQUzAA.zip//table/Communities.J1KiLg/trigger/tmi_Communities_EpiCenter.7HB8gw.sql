CREATE TRIGGER "tmi_Communities_EpiCenter" AFTER INSERT ON "Communities"
FOR EACH ROW BEGIN
UPDATE geometry_columns_time SET last_insert = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
WHERE Lower(f_table_name) = Lower('Communities') AND Lower(f_geometry_column) = Lower('EpiCenter');
END;

