CREATE VIEW vector_layers_auth AS
SELECT 'SpatialTable' AS layer_type, f_table_name AS table_name, f_geometry_column AS geometry_column, read_only AS read_only, hidden AS hidden
FROM geometry_columns_auth
UNION
SELECT 'SpatialView' AS layer_type, a.view_name AS table_name, a.view_geometry AS geometry_column, b.read_only AS read_only, a.hidden AS hidden
FROM views_geometry_columns_auth AS a
JOIN views_geometry_columns AS b ON (Upper(a.view_name) = Upper(b.view_name) AND Upper(a.view_geometry) = Upper(b.view_geometry))
UNION
SELECT 'VirtualShape' AS layer_type, virt_name AS table_name, virt_geometry AS geometry_column, 1 AS read_only, hidden AS hidden
FROM virts_geometry_columns_auth;

