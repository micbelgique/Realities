CREATE TRIGGER vwgcs_view_geometry_insert
BEFORE INSERT ON 'views_geometry_columns_statistics'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on views_geometry_columns_statistics violates constraint: view_geometry value must not contain a single quote')
WHERE NEW.view_geometry LIKE ('%''%');
SELECT RAISE(ABORT,'insert on views_geometry_columns_statistics violates constraint: 
view_geometry value must not contain a double quote')
WHERE NEW.view_geometry LIKE ('%"%');
SELECT RAISE(ABORT,'insert on views_geometry_columns_statistics violates constraint: view_geometry value must be lower case')
WHERE NEW.view_geometry <> lower(NEW.view_geometry);
END;

