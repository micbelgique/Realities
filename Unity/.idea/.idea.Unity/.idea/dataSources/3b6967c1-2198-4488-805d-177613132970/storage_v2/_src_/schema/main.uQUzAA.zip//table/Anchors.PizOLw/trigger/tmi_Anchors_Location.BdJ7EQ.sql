CREATE TRIGGER "tmi_Anchors_Location" AFTER INSERT ON "Anchors"
FOR EACH ROW BEGIN
UPDATE geometry_columns_time SET last_insert = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
WHERE Lower(f_table_name) = Lower('Anchors') AND Lower(f_geometry_column) = Lower('Location');
END;

