CREATE TRIGGER "ggu_Communities_EpiCenter" BEFORE UPDATE OF "EpiCenter" ON "Communities"
FOR EACH ROW BEGIN
SELECT RAISE(ROLLBACK, 'Communities.EpiCenter violates Geometry constraint [geom-type or SRID not allowed]')
WHERE (SELECT geometry_type FROM geometry_columns
WHERE Lower(f_table_name) = Lower('Communities') AND Lower(f_geometry_column) = Lower('EpiCenter')
AND GeometryConstraints(NEW."EpiCenter", geometry_type, srid) = 1) IS NULL;
END;

