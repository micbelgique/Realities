CREATE TRIGGER gcau_f_geometry_column_update
BEFORE UPDATE OF 'f_geometry_column' ON 'geometry_columns_auth'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'update on geometry_columns_auth violates constraint: f_geometry_column value must not contain a single quote')
WHERE NEW.f_geometry_column LIKE ('%''%');
SELECT RAISE(ABORT,'update on geometry_columns_auth violates constraint: f_geometry_column value must not contain a double quote')
WHERE NEW.f_geometry_column LIKE ('%"%');
SELECT RAISE(ABORT,'update on geometry_columns_auth violates constraint: f_geometry_column value must be lower case')
WHERE NEW.f_geometry_column <> lower(NEW.f_geometry_column);
END;

