CREATE TRIGGER "ggu_Anchors_Location" BEFORE UPDATE OF "Location" ON "Anchors"
FOR EACH ROW BEGIN
SELECT RAISE(ROLLBACK, 'Anchors.Location violates Geometry constraint [geom-type or SRID not allowed]')
WHERE (SELECT geometry_type FROM geometry_columns
WHERE Lower(f_table_name) = Lower('Anchors') AND Lower(f_geometry_column) = Lower('Location')
AND GeometryConstraints(NEW."Location", geometry_type, srid) = 1) IS NULL;
END;

