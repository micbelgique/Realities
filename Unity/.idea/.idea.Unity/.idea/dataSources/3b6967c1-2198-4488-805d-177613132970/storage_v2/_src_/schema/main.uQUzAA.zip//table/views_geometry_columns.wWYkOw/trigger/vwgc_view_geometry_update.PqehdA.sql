CREATE TRIGGER vwgc_view_geometry_update
BEFORE UPDATE OF 'view_geometry' ON 'views_geometry_columns'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'update on views_geometry_columns violates constraint: view_geometry value must not contain a single quote')
WHERE NEW.view_geometry LIKE ('%''%');
SELECT RAISE(ABORT,'update on views_geometry_columns violates constraint: 
view_geometry value must not contain a double quote')
WHERE NEW.view_geometry LIKE ('%"%');
SELECT RAISE(ABORT,'update on views_geometry_columns violates constraint: view_geometry value must be lower case')
WHERE NEW.view_geometry <> lower(NEW.view_geometry);
END;

